import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusappComponent } from './busapp.component';

describe('BusappComponent', () => {
  let component: BusappComponent;
  let fixture: ComponentFixture<BusappComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BusappComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BusappComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
