export class bus {
    bus_id: number=0 ;
	bus_name: string | undefined;
	arrival_time: string | undefined;
    departure_time: string | undefined;
    source: string | undefined;
    destination: string | undefined;
    cost_per_seat:number=0 ;
    no_of_seats:number=0 ;
	
}