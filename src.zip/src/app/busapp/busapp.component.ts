import { Component, OnInit } from '@angular/core';
import { BusService } from '../bus.service';
import { bus } from './bus';

@Component({
  selector: 'app-busapp',
  templateUrl: './busapp.component.html',
  styleUrls: ['./busapp.component.css']
})
export class BusappComponent implements OnInit {

busobj: bus = new bus();

busarray : bus[]=[] ;
 

  ngOnInit(): void {
  }

  constructor(private busService:BusService) { }


  getAllBus() 
  {
    console.log('getAllBus()--> invoking getAllBusService()...');
    this.busService.getAllBusService().subscribe(
      (data: bus[])=> //srping data is pushed into this data variable
      {
        this.busarray = data; //assign data to allFriends so that html can fetch it in tr td tags
        console.log(this.busarray);
      }, 
      (err) => {
        console.log(err);
      }
    ); 
  }



  addBus()//this is called on click of the button
   {
    console.log('addBus()--> invoking addBusService()...');
    this.busService.addBusService(this.busobj).subscribe(
      (data: bus)=> //srping data is pushed into this data variable
      {
        this.busobj = data; //assign data to allFriends so that html can fetch it in tr td tags
        console.log(this.busobj);
        this.getAllBus();
      }, 
      (err) => {
        console.log(err);
      }
    ); 
  }



}
