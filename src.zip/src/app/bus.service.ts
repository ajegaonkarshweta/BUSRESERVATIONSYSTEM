import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { bus } from './busapp/bus';


@Injectable({
  providedIn: 'root'
})
export class BusService {

  constructor(private myHttp: HttpClient) { }

  getAllBusService() : Observable<bus[]> 
  {
    console.log('getAllBusService() invoked...');
    return this.myHttp.get<bus[]>("http://localhost:8080/ticketJPA/getBus");
  }


addBusService(newBus: bus) {
  console.log('addBusService() invoked...');
  return this.myHttp.post<bus>("http://localhost:8080/ticketJPA/addbus",newBus);
}


}

