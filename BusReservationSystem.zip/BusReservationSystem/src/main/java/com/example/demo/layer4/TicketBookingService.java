package com.example.demo.layer4;

import java.util.List;

import com.example.demo.layer2.Ticketbooking;


public interface TicketBookingService {

	public List<Ticketbooking> findAllAvailableBusService();
	
	public Ticketbooking  createBusService(Ticketbooking bus); //C

	
}
