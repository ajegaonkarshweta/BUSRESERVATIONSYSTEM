package com.example.demo.layer5;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Ticketbooking;
import com.example.demo.layer4.TicketBookingService;

@CrossOrigin
@RestController
@RequestMapping("/ticketJPA")
public class TicketBookingJPAController {

	@Autowired
	TicketBookingService ticketService;

	private List<Ticketbooking> busList = new ArrayList<Ticketbooking>(); //global

	public TicketBookingJPAController() {
		System.out.println("TicketBookingJPAController: TicketBookingJPAController() ctor...");

	}


	@GetMapping("/getBus") // http://localhost:8080/ticketJPA/getBus
	public List<Ticketbooking>  getAllBuses() {
		System.out.println("TicketBookingController: /ticketJPA/getBus/");
		return ticketService.findAllAvailableBusService(); //controller is invoking service

	}


	//open postman, create new request, select POST, enter request BODY, send
	@PostMapping("/addbus") //  http://localhost:8080/ticketJPA/addbus
	public  Ticketbooking addBus(@RequestBody Ticketbooking newbus) {
		System.out.println("TicketBookingController: /ticket/addbus/"+newbus.getBus_id()+" "+newbus.getBus_name()+"  "
				+newbus.getArrival_time()+" " +newbus.getDeparture_time()+"" +newbus.getSource()+""+newbus.getDestination());


		ticketService.createBusService(newbus);
		return newbus;

	}

}
