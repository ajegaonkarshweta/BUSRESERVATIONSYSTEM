package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Ticketbooking;
import com.example.demo.layer3.TicketBookingRepository;
import com.example.demo.layer3.TicketBookingRepositoryImpl;


@Service
public class TicketBookingServiceImpl implements TicketBookingService {

	
	@Autowired
	TicketBookingRepository ticketRepo;
	TicketBookingRepositoryImpl ticketRepositoryImpl;
	
	@Override
	public List<Ticketbooking> findAllAvailableBusService() {
		// TODO Auto-generated method stub
		System.out.println("AvailableBusService:findAllAvailableBusService ");
		return ticketRepo.getAvailableBus();
		
	}

	


	@Override
	public Ticketbooking createBusService(Ticketbooking bus) {
		// TODO Auto-generated method stub
		return  ticketRepo.insertBus(bus);
		
	}

}
