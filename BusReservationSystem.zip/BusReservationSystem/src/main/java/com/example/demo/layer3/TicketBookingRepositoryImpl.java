package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;


import com.example.demo.layer2.Ticketbooking;

@Repository
public class TicketBookingRepositoryImpl implements TicketBookingRepository {

	
	@PersistenceContext
	EntityManager entityManager;
	
	
	public TicketBookingRepositoryImpl()
	{
		System.out.println("TicketBookingRepositoryImpl constructed..");
	}
	
	
	@Override
	//@Transactional
	public List<Ticketbooking> getAvailableBus() {
		// TODO Auto-generated method stub
		Query query = entityManager.createQuery("from Ticketbooking");
		return query.getResultList();
		
	}



	@Override
	@Transactional
	public Ticketbooking insertBus(Ticketbooking bus) {
		// TODO Auto-generated method stub
		entityManager.persist(bus);
		return bus;
		
	}

	
}
