package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController  // to generate REST JSON,HTML,XML
@RequestMapping("/bank") //URI
public class Greeting {
	
	
	@RequestMapping("/services") //nested URI
	public String[] bankServices() { //localhost:8080/bank/services
		String ourservices[]= {"Personal banking","Fixed Deposits","PPF"};
		return ourservices;
	}
	
	@RequestMapping("/greet") //nested URI
	public String greetMe() { //localhost:8080/bank/greet
		return "Welcome to online banking";
	}
	
	
	@RequestMapping("/bye") //nested URI
	public String logoutMe() { //localhost:8080/bank/bye
		return "Hope you liked online banking...";
	}
	
	
	
}
