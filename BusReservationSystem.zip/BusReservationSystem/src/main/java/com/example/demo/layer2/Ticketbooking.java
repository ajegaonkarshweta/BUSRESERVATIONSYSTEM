package com.example.demo.layer2;

import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="tbl_bus")
public class Ticketbooking {

	@Id
	@Column(name="bus_id")
	private int bus_id;
	
	@Column(name="bus_name")
	private String bus_name;
	
	@Column(name="arrival_time")
	private String arrival_time;
	
	@Column(name="departure_time")
	private String departure_time;
	
	@Column(name="source")
	private String source;
	
	@Column(name="destination")
	private String destination;
	
	
	@Column(name="no_of_seats")
	private int no_of_seats;
	
	@Column(name="cost_per_seat")
	private int cost_per_seat;



	public Ticketbooking() {
		super();
		// TODO Auto-generated constructor stub
	}


	
	
	public Ticketbooking(int bus_id, String bus_name, String arrival_time, String departure_time, String source,
			String destination, int no_of_seats, int cost_per_seat) {
		super();
		this.bus_id = bus_id;
		this.bus_name = bus_name;
		this.arrival_time = arrival_time;
		this.departure_time = departure_time;
		this.source = source;
		this.destination = destination;
		this.no_of_seats = no_of_seats;
		this.cost_per_seat = cost_per_seat;
	}




	public int getBus_id() {
		return bus_id;
	}


	public void setBus_id(int bus_id) {
		this.bus_id = bus_id;
	}


	public String getBus_name() {
		return bus_name;
	}


	public void setBus_name(String bus_name) {
		this.bus_name = bus_name;
	}




	public String getArrival_time() {
		return arrival_time;
	}



	public void setArrival_time(String arrival_time) {
		this.arrival_time = arrival_time;
	}




	public String getDeparture_time() {
		return departure_time;
	}



	public void setDeparture_time(String departure_time) {
		this.departure_time = departure_time;
	}



	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}




	public int getNo_of_seats() {
		return no_of_seats;
	}




	public void setNo_of_seats(int no_of_seats) {
		this.no_of_seats = no_of_seats;
	}




	public int getCost_per_seat() {
		return cost_per_seat;
	}




	public void setCost_per_seat(int cost_per_seat) {
		this.cost_per_seat = cost_per_seat;
	}


		
	
}
