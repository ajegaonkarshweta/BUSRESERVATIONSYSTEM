package com.example.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


import com.example.demo.layer2.Ticketbooking;
import com.example.demo.layer3.TicketBookingRepository;

@SpringBootTest
class BusReservationSystemApplicationTests {

	@Autowired
	TicketBookingRepository ticketRepo;

	@Test
	void showAllBusTest() {
		List<Ticketbooking> busList =  ticketRepo.getAvailableBus();

		for(Ticketbooking theBus :busList) {
			System.out.println("Bus Id   : "+theBus.getBus_id());
			System.out.println("Bus Name     : "+theBus.getBus_name());
			System.out.println("Arrival Time : "+theBus.getArrival_time());
			System.out.println("Departure Time : "+theBus.getDeparture_time());
			System.out.println("Source : "+theBus.getSource());
			System.out.println("Destination : "+theBus.getDestination());
			System.out.println("Cost_per_seat : "+theBus.getCost_per_seat());
			System.out.println("No_of_seat : "+theBus.getNo_of_seats());


			System.out.println("---------------");
		}
	}

	@Test
	public void addNewBus() {
		Ticketbooking newBus = new Ticketbooking();

		newBus.setBus_id(30);
		newBus.setBus_name("shivneri");
		newBus.setArrival_time("06:00:00");
		newBus.setDeparture_time("06:15:10");
		newBus.setSource("Delhi");
		newBus.setDestination("Mumbai");
		newBus.setCost_per_seat(400);
		newBus.setNo_of_seats(8);


		ticketRepo.insertBus(newBus);



	}

}
